/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#include <stdio.h>
#include <stdint.h>
// Alt efter hvilket tegn der bliver modtaget over UART, ændres de forskellige modes.
void handleByteReceived(uint8_t byteReceived);


/* [] END OF FILE */
